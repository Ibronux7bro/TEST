from app import db

from app.models.base import BaseModel
from app.models.role import Role
from app.models.user import User
from app.models.permission import Permission
from app.models.customer import Customer
from app.models.product import Product
from app.models.invoice import Invoice
from app.models.invoice_product import InvoiceProduct

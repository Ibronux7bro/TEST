from app import create_app, db
from app.models.role import Role
from app.models.permission import Permission

app = create_app()

with app.app_context():
    print("--- SEEDING ALL PERMISSIONS ---")
    try:
        admin_role = Role.query.filter_by(name='Admin').first()
        if not admin_role:
            print("Error: Admin role not found!")
            exit(1)
            
        print(f"Found Admin Role ID: {admin_role.id}")
        
        models = ['Invoice', 'Product', 'Customer']
        
        for model in models:
            perm = Permission.query.filter_by(
                role_id=admin_role.id,
                model_name=model
            ).first()
            
            if perm:
                print(f"Permissions for {model} already exist. Updating...")
                perm.can_create = True
                perm.can_read = True
                perm.can_update = True
                perm.can_delete = True
            else:
                print(f"Creating permissions for {model}...")
                perm = Permission(
                    role_id=admin_role.id,
                    model_name=model,
                    can_create=True,
                    can_read=True,
                    can_update=True,
                    can_delete=True
                )
                db.session.add(perm)
            
        db.session.commit()
        print("Successfully seeded ALL permissions for Admin.")
        
    except Exception as e:
        db.session.rollback()
        print(f"Error seeding permissions: {e}")
    print("--- END SEED ---")

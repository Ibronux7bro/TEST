from app import create_app, db
from app.models.role import Role
from app.models.permission import Permission
from app.models.product import Product
from app.models.invoice import Invoice
from sqlalchemy import text

app = create_app()

with app.app_context():
    print("=== SYSTEM VERIFICATION REPORT ===")
    
    # 1. DB Connection
    try:
        db.session.execute(text('SELECT 1'))
        print("[OK] Database Connection")
    except Exception as e:
        print(f"[FAIL] Database Connection: {e}")
        exit(1)

    # 2. Role Check
    admin = Role.query.filter_by(name='Admin').first()
    if admin:
        print(f"[OK] Admin Role Found (ID: {admin.id})")
    else:
        print("[FAIL] Admin Role NOT Found")

    # 3. Product Permissions Check
    if admin:
        perm = Permission.query.filter_by(role_id=admin.id, model_name='Product').first()
        if perm:
            status = []
            if perm.can_create: status.append("Create")
            if perm.can_read: status.append("Read")
            if perm.can_update: status.append("Update")
            if perm.can_delete: status.append("Delete")
            print(f"[OK] Product Permissions for Admin: {', '.join(status)}")
            
            if not perm.can_read:
                print("   [WARNING] 'Read' permission is missing! Products list will be empty.")
        else:
            print("[FAIL] No Product Permissions found for Admin! (Run seed_product_permissions.py)")

    # 4. Data Counts
    p_count = Product.query.count()
    i_count = Invoice.query.count()
    print(f"[INFO] Total Products: {p_count}")
    print(f"[INFO] Total Invoices: {i_count}")

    print("=== END REPORT ===")

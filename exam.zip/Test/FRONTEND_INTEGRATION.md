# Frontend-Backend Integration Guide

This document explains how the frontend has been connected to the existing Flask backend APIs.

## Overview

The frontend now communicates with the backend through RESTful API endpoints using JWT authentication. The backend remains **completely unchanged** - all existing logic, permissions, and routes are preserved.

## Files Modified/Created

### New JavaScript Files

1. **`static/js/api.js`** - Core API integration module
   - JWT token management
   - API endpoint wrappers
   - Role-based UI helpers
   - Error handling

2. **`static/js/invoice-list.js`** - Invoice list functionality
   - Loads invoices from `/api/invoices`
   - Role-based UI (hide/show delete/update buttons)
   - Status change functionality for authorized roles

3. **`static/js/invoice-create.js`** - Invoice creation functionality
   - Loads customers and products from APIs
   - Inventory validation before submission
   - Form submission to `/api/invoices`

4. **`static/js/common.js`** - Shared functionality
   - Navigation updates with user info
   - Authentication checks
   - Role-based UI visibility

### Updated Files

1. **`templates/login.html`** - Updated to use new API
2. **`templates/layout.html`** - Added API scripts
3. **`templates/invoices/list.html`** - Converted to API-driven
4. **`templates/invoices/create.html`** - Updated for API integration
5. **`static/js/login.js`** - Updated to use new API

## API Integration Details

### Authentication Flow

1. **Login**: POST `/login` with email/password
2. **Token Storage**: JWT stored in localStorage
3. **API Calls**: All requests include `Authorization: Bearer <token>`
4. **Auto-logout**: On 401 responses, redirect to login

### API Endpoints Used

| Endpoint | Method | Purpose | Authentication |
|----------|--------|---------|---------------|
| `/login` | POST | User authentication | None |
| `/me` | GET | Current user info | JWT |
| `/api/invoices` | GET | List invoices | JWT |
| `/api/invoices` | POST | Create invoice | JWT |
| `/api/invoices/{id}/items` | GET | Invoice details | JWT |
| `/api/invoices/{id}/status` | PUT | Update status | JWT |
| `/api/customers` | GET | List customers | JWT |
| `/api/products` | GET | List products | JWT |

### Role-Based UI Behavior

The frontend adjusts UI based on user role **without enforcing permissions** (backend handles enforcement):

- **Admin**: All buttons visible
- **Sales Manager**: Create/Update visible, Delete hidden for invoices
- **Sales Employee**: Create/Read visible, Update/Delete hidden
- **Cashier**: Create/Read visible, Update/Delete hidden

### Error Handling

- **401 Unauthorized**: Auto-redirect to login
- **403 Forbidden**: Show "Access denied" message
- **400/404**: Display backend error messages
- **Network errors**: Show generic error message

## Key Features

### 1. JWT-Only Authentication
- No session-based authentication
- Tokens stored securely in localStorage
- Automatic token refresh on expiration

### 2. Role-Based UI
- Hide/show elements based on user role
- Better UX without compromising security
- Backend still enforces all permissions

### 3. Real-Time Validation
- Inventory validation before invoice creation
- Stock availability checking
- Backend validation errors displayed

### 4. Seamless Integration
- Existing backend routes unchanged
- Same HTTP methods and endpoints
- Compatible with existing RBAC system

## Usage Instructions

1. **Run Backend**: Start Flask server on `http://127.0.0.1:5000`
2. **Initialize Roles**: Run `python init_roles_and_permissions.py`
3. **Access Frontend**: Open `http://127.0.0.1:5000/login`
4. **Login**: Use sample users:
   - Admin: `admin@test.com` / `admin123`
   - Sales Manager: `manager@test.com` / `manager123`
   - Sales Employee: `employee@test.com` / `employee123`
   - Cashier: `cashier@test.com` / `cashier123`

## Security Notes

- **Backend Enforcement**: All permissions enforced by backend
- **UI Hints Only**: Frontend role-based UI is for UX only
- **JWT Security**: Tokens validated on every request
- **No Sensitive Data**: Passwords never stored in frontend

## Browser Compatibility

- Modern browsers with ES6 support
- LocalStorage support required
- Fetch API support required

## Testing

Test with different user roles to verify:
1. Permission-based UI visibility
2. API access control
3. Error handling
4. Role-based functionality

The frontend now fully integrates with the existing backend while maintaining all backend logic and security measures.

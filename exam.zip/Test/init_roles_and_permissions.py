from app import create_app, db
from app.models.role import Role
from app.models.permission import Permission
from app.models.user import User
from app.services.role_service import RoleService
from werkzeug.security import generate_password_hash

def init_roles_and_permissions():
    """Initialize role hierarchy and permissions"""
    app = create_app()
    
    with app.app_context():
        print("Creating role hierarchy...")
        
        # Create role hierarchy
        role_map = RoleService.create_role_hierarchy()
        print(f"Created roles: {list(role_map.keys())}")
        
        # Define permissions for each role
        permissions_config = {
            'Admin': {
                'User': ['create', 'read', 'update', 'delete'],
                'Customer': ['create', 'read', 'update', 'delete'],
                'Product': ['create', 'read', 'update', 'delete'],
                'Invoice': ['create', 'read', 'update', 'delete'],
                'Role': ['create', 'read', 'update', 'delete'],
                'Permission': ['create', 'read', 'update', 'delete']
            },
            'Sales Manager': {
                'User': ['read', 'update'],  # Can read and update users
                'Customer': ['create', 'read', 'update', 'delete'],
                'Product': ['create', 'read', 'update', 'delete'],
                'Invoice': ['create', 'read', 'update'],  # Can change status but not delete
                'Role': ['read'],
                'Permission': ['read']
            },
            'Sales Employee': {
                'User': ['read'],  # Can only read users
                'Customer': ['create', 'read', 'update'],
                'Product': ['read'],
                'Invoice': ['create', 'read'],  # Can create and read invoices
                'Role': ['read'],
                'Permission': ['read']
            },
            'Cashier': {
                'User': ['read'],  # Can only read users
                'Customer': ['read'],
                'Product': ['read'],
                'Invoice': ['create', 'read'],  # Can create and read invoices only
                'Role': ['read'],
                'Permission': ['read']
            }
        }
        
        print("Creating permissions...")
        
        # Clear existing permissions
        Permission.query.delete()
        db.session.commit()
        
        # Create permissions
        for role_name, models_permissions in permissions_config.items():
            if role_name not in role_map:
                print(f"Warning: Role {role_name} not found in role map")
                continue
                
            role_id = role_map[role_name]
            
            for model_name, actions in models_permissions.items():
                permission = Permission(
                    role_id=role_id,
                    model_name=model_name,
                    can_create='create' in actions,
                    can_read='read' in actions,
                    can_update='update' in actions,
                    can_delete='delete' in actions
                )
                db.session.add(permission)
        
        db.session.commit()
        
        # Create admin user if not exists
        admin_role = Role.query.filter_by(name='Admin').first()
        if admin_role:
            existing_admin = User.query.filter_by(email='admin@test.com').first()
            if not existing_admin:
                admin_user = User(
                    name='System Administrator',
                    email='admin@test.com',
                    role_id=admin_role.id,
                    status=True
                )
                admin_user.set_password('admin123')
                db.session.add(admin_user)
                db.session.commit()
                print("Created admin user: admin@test.com / admin123")
        
        # Create sample users for each role
        sample_users = [
            ('Sales Manager', 'manager@test.com', 'manager123'),
            ('Sales Employee', 'employee@test.com', 'employee123'),
            ('Cashier', 'cashier@test.com', 'cashier123')
        ]
        
        for role_name, email, password in sample_users:
            role = Role.query.filter_by(name=role_name).first()
            if role:
                existing_user = User.query.filter_by(email=email).first()
                if not existing_user:
                    user = User(
                        name=f'Sample {role_name}',
                        email=email,
                        role_id=role.id,
                        status=True
                    )
                    user.set_password(password)
                    db.session.add(user)
        
        db.session.commit()
        
        print("\n=== Role Hierarchy ===")
        for role_name in RoleService.ROLE_HIERARCHY.keys():
            role = Role.query.filter_by(name=role_name).first()
            if role:
                parent_name = "None (Top Level)"
                if role.parent_role_id:
                    parent = Role.query.get(role.parent_role_id)
                    parent_name = parent.name if parent else "Unknown"
                print(f"{role_name} (ID: {role.id}) -> Parent: {parent_name}")
        
        print("\n=== Permissions ===")
        for role_name in RoleService.ROLE_HIERARCHY.keys():
            role = Role.query.filter_by(name=role_name).first()
            if role:
                print(f"\n{role_name}:")
                permissions = Permission.query.filter_by(role_id=role.id).all()
                for perm in permissions:
                    actions = []
                    if perm.can_create: actions.append('create')
                    if perm.can_read: actions.append('read')
                    if perm.can_update: actions.append('update')
                    if perm.can_delete: actions.append('delete')
                    print(f"  {perm.model_name}: {', '.join(actions) if actions else 'none'}")
        
        print("\n=== Sample Users ===")
        print("Admin: admin@test.com / admin123")
        print("Sales Manager: manager@test.com / manager123")
        print("Sales Employee: employee@test.com / employee123")
        print("Cashier: cashier@test.com / cashier123")
        
        print("\nRoles and permissions initialized successfully!")

if __name__ == "__main__":
    init_roles_and_permissions()
